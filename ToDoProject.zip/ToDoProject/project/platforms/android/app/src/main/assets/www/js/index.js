$(function(){


  if (!sessionStorage.loggedIn==null || sessionStorage.loggedin==null){
      location.href="home.html"
  }
  
  var link1 = crossroads.addRoute("/logout",function(){
      sessionStorage.clear();
      location="home.html";
  });
  
 
  })